<template>
  <div id="home" class="home">
    <input type="file" id="file" name="myfile" />
    <div
      id="inputContent"
      class="edit"
      placeholder="请在这输入内容"
      contenteditable="true"
      @onblur="blurEdit"
      @onfocus="focusEdit"
      @oninput="changeText"
    ></div>
    <button @click="clickInsert">clickInsert</button>
  </div>
</template>

<script>
// @ is an alias to /src
import xss from 'xss';
export default {
  name: 'HomeView',
  components: {},
  data() {
    return {
      position: '',
    };
  },
  mounted() {
    this.initSertNode();
  },
  methods: {
    initSertNode() {
      let dom = document.createElement('wise');
      // const idDom = '1 onmouseover=confirm(1)' + ' ' + ` background="javascript:alert(/xss/)"`;
      let fileObj = document.getElementById('file').files[0];
      console.log('fileObj', fileObj);
      let nameTmp = "1'" + `onmouseover=confirm(1) src='1`;
      dom.id = fileObj.name;
      dom.innerText = '测试点击';
      console.log(dom, dom.outerHTML.replaceAll('"', ''));
      dom.innerHTML = dom.outerHTML.replaceAll('"', '');
      let str = `<wise id='${nameTmp}'>${fileObj.name}</wise>`;
      dom.innerHTML = str;
      console.log('xxx', xss(str));
      return dom;
    },
    blurEdit() {
      this.position = window.getSelection().getRangeAt(0);
    },
    focusEdit() {},
    changeText() {},
    clickInsert() {
      if (this.position === '') {
        // 如果div没有光标，则在div内容末尾插入
        const div = document.getElementById('inputContent');
        div.focus();
        const range = window.getSelection();
        range.selectAllChildren(div);
        range.collapseToEnd();
        this.position = window.getSelection().getRangeAt(0);
      }
      // 将按钮插入
      this.position.insertNode(this.initSertNode());
    },
  },
};
</script>
<style>
wise {
  border: 1px solid seagreen;
  height: 30px;
  color: azure;
  width: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  background: seagreen;
}
.edit[contenteditable]:empty:before {
  content: attr(placeholder);
  color: #cccccc;
}
.edit[contenteditable]:focus {
  content: none;
}
</style>
