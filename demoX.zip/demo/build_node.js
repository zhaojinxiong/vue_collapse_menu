const { exec } = require("child_process");
// 就是进行简单`判断`在执行环境下应该使用`哪个命令行`执行命令;
// process.platform : 标识Node.js进程运行其上的操作系统平台
// 返回值：‘aix’,‘darwin’,‘freebsd’,‘linux’,‘openbsd’,‘sunos’,‘win32’
console.log(`This platform is ${process.platform}`);
// 7z a dist.zip dist/*
// rm -rf dist
// mv dist.zip ../dist.zip
exec("7z a dist.zip dist/*");
exec("rm -rf dist");
exec("mv dist.zip ../dist.zip");

// exec(
//   "ls -la",
//   { shell: process.platform === "win32" },
//   (error, stdout, stderr) => {
//     if (error) {
//       console.error(`执行出错: ${error}`);
//       return;
//     }
//     console.log(`stdout: ${stdout}`);
//   }
// );
