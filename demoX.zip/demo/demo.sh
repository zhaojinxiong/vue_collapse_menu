7z a dist.zip dist/*
rm -rf dist
mv dist.zip ../dist.zip